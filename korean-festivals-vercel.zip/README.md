# Korean Festivals · 한국의 축제
Static site (no build step). SRM Institute of Science and Technology · 26LCA1006J

## Deploy on Vercel
**Dashboard:** push this folder to GitHub → vercel.com/new → import repo → Framework Preset "Other" → leave Build Command and Output Directory empty → Deploy.
**CLI:** `npm i -g vercel` then run `vercel --prod` inside this folder.

Local preview: `npx serve .`
